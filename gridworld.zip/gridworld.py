
import numpy as np
import matplotlib.pyplot as plt
from GridworldHelper import *

# TODO - Create a variable named env and set it equal to a GridworldHelper object

# TODO - Use env to call show_grid() which will display the initial grid

# TODO - Create a q_table variable that will hold an array with the same size as the grid and a depth equal to the number of actions (up,down,left,right)
# np.zeros() will create this for us if we pass it three parameters
# parameter 1: grid height or env.dim[0]
# parameter 2: grid width or enc.dim[1]
# parameter 3: number of possible actions, in this case 4 possible actions

# Parameters
num_episodes = 1000
gamma = 0.99
eps = 0.05
lr = 0.01

# Empty lists to track the number of rewards
ep_rewards = []
n_steps = []

# Loop through the algorithm
for ep in range(num_episodes):
    print('--------- Episode '+str(ep)+" ---------")
    s_0 = env.reset()
    done = False
    rewards = 0
    while done == False:
        # TODO - Create an if-else statement
        # Generate a random number with np.random.rand()
        # If the random number is less than the epsilon probability stored in the variable 'eps', choose a random action using np.random.choice(options)
        # The options are stored in the environment's action_space variable
        # Otherwise, set action to the maximum of q_table[s_0[0], s_0[1]] using np.argmax()

        # TODO - Below, call step on the env with the chosen action
        s_1, reward, done =
        env.show_state()

        # Update the Q-table
        current_state = q_table[s_0[0], s_0[1], action]
        # TODO - Finish updating the Q-table
        # Use the equation: current_state + learningrate*(reward + gamma* max(q_table[s_1[0], s_1[1]]) -  current_state)
        # Some of the variables in that equation need to be replaced
        q_table[s_0[0], s_0[1], action] =

        s_0 = s_1.copy()
        rewards += reward
        if done:
            ep_rewards.append(rewards)

# Calculate rolling average and plot results
mean_rewards = [np.mean(ep_rewards[n-10:n]) if n > 10 else np.mean(ep_rewards[:n])
               for n in range(1, len(ep_rewards))]
plt.figure(figsize=(12,8))
plt.plot(ep_rewards)
plt.plot(mean_rewards)
plt.title('Gridworld Rewards')
plt.xlabel('Episode')
plt.ylabel('Reward')
plt.savefig('rewards.png')

env.plot_policy(q_table)
